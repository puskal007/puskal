
let modelName = "XYZ";
let duration = 0; 

function recalculate() {
    let costLabel = document.getElementById("calculated-cost");
    let totalCost;
    if (modelName === "XYZ") {
        totalCost = duration * 100;
    } else if (modelName === "CPRG") {
        totalCost = duration * 213;
    }
    
    costLabel.innerHTML = "$" + totalCost;
}


let modelButton = document.getElementById("switch-model");

function changeModel() {
   
    let modelText = document.getElementById("model-text");
    
   
    if (modelName === "XYZ") {
        modelName = "CPRG";
        modelText.innerHTML = "Model CPRG";
    } else if (modelName === "CPRG") {
        modelName = "XYZ";
        modelText.innerHTML = "Model XYZ";
    }
    
    recalculate();
}


modelButton.addEventListener("click", changeModel);


let durationButton = document.getElementById("change-duration");

function changeDuration() {
    let durationText = document.getElementById("duration-text");
    
    let newDuration = prompt("Enter the new duration in months:");
    
    duration = Number(newDuration);
    
    durationText.innerHTML = duration + " months";
    
    recalculate();
}

durationButton.addEventListener("click", changeDuration);

function generateGitHubPagesURL(username, repoName) {
    return "https://" + username + ".github.io/" + repoName;
}


let username = "puskal007"; 
let repoName = "puskal";

let websiteURL = generateGitHubPagesURL(username, repoName);
console.log("Your website URL is:", websiteURL);
